package com.technicalyorker.calculator.constants;

/**
 * 
 * @author achuth
 *
 */
public class Constants {

}
