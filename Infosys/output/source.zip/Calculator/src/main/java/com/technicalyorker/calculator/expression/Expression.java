package com.technicalyorker.calculator.expression;

/**
 * All Expressions are defined by this class.
 * 
 * @author achuth
 *
 */
public interface Expression {
	public Double evaluate();
}
