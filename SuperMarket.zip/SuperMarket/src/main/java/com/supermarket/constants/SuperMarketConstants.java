package com.supermarket.constants;

/**
 * The type Super market constants.
 */
public class SuperMarketConstants {
    /**
     * The constant STERLING.
     */
    public static final String STERLING = "£";
}
