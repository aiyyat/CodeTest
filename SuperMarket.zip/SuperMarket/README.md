# SuperMarkets

# FAQ

## Why did you implement your own Billing Observer?

## How would I extend the framework to add Bill Level Discounts e.g. Date Based Discount for whole bill

## How would I extend the framework to add Bill Level Discounts e.g. Conflicting Rules

e.g. 3 strawberries for $15 & 6 strabberies for $25
